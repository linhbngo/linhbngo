#!/bin/bash

echo 'AA=' $AA
echo 'BB=' $BB
