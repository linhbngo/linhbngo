#!/bin/bash

unset opt_a; unset opt_b; unset opt_c; unset opt_d
unset optarg_c; unset optarg_d;

while getopts "abc:d:" flag; do
  [ "$flag" = "?" ] && exit 1;
  eval "opt_$flag=1"
  if [ "$flag" = "c" -o "$flag" = "d" ]; then
    eval "optarg_$flag=$OPTARG"
  fi
done
shift $((OPTIND-1))

echo "opt_a=$opt_a; opt_b=$opt_b; opt_c=$opt_c;"
echo "optarg_c=$optarg_c;"
echo "optarg_d=$optarg_d;"

echo "non-opts=$@"
