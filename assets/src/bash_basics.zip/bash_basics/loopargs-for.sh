#!/bin/bash

for i in "$@"; do
  echo "$i"
done
