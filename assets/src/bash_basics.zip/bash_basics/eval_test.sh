#!/bin/bash

SRC="~/bin"

echo "----------- 1"
cmd="ls $SRC"
eval "$cmd"

echo "----------- 2"
ls $SRC
