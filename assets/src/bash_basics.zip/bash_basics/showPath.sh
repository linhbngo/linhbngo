#!/bin/bash

path
