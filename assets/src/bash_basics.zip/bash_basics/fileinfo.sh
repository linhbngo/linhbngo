#!/bin/bash

for x in *; do
  file "$x"
done
