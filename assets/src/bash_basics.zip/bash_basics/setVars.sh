#!/bin/bash

AA='hello'
export BB='world'
